Your new navbar link and component will be called "Contact"

First, add the app folder to your src directory.  Delete your other app files. Once those files have been added, go onto the next steps.

Here are the steps you will need to do -
1. Run a command in the terminal to add/generate the component
2. Add a link to this file: src/app/nav/nav.component.html
3. Update the routing in /src/app/app-routing.module.ts
